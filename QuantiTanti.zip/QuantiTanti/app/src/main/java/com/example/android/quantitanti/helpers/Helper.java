package com.example.android.quantitanti.helpers;

import android.text.InputFilter;
import android.text.Spanned;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Helper {


    public static String fromLowerCaseToFirstCapitalizedLetter(String word) {
        String wordCapitalized = word.substring(0,1).toUpperCase() + word.substring(1);
        return wordCapitalized;
    }

    public static String fromUperCaseToFirstCapitalizedLetter(String word) {
        String wordCapitalized = word.substring(0,1) + word.substring(1).toLowerCase();
        return wordCapitalized;
    }




}
