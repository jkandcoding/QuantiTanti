package com.example.android.quantitanti.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.android.quantitanti.R;
import com.example.android.quantitanti.database.CostEntry;
import com.example.android.quantitanti.database.DailyExpensesView;

import java.util.List;

public class DailyCostAdapter extends RecyclerView.Adapter<DailyCostAdapter.DailyCostViewHolder> {

    // Member variable to handle item clicks
    final private DailyItemClickListener mDailyItemClickListener;

    // Class variables for the List that holds cost data and the Context
    private List<CostEntry> mCostEntries;
    private List<DailyExpensesView> mDailyExpenses;
    private Context mContext;

    //private ImageView imgv_category;

    public DailyCostAdapter(DailyItemClickListener listener, Context context) {
        mDailyItemClickListener = listener;
        mContext = context;
    }

    /**
     * Called when ViewHolders are created to fill a RecyclerView.
     *
     * @return A new DailyCostViewHolder that holds the view for daily costs
     */
    @NonNull
    @Override
    public DailyCostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Inflate the layout to the view
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.one_cost_item_view, parent, false);

        return new DailyCostViewHolder(view);
    }

    /**
     * Called by the RecyclerView to display data at a specified position in the Cursor.
     *
     * @param holder   The ViewHolder to bind Cursor data to
     * @param position The position of the data in the Cursor
     */
    @Override
    public void onBindViewHolder(@NonNull DailyCostViewHolder holder, int position) {
        // Determine the values of the wanted data
        CostEntry costEntry = mCostEntries.get(position);
       // DailyExpensesView dailyExpens = mDailyExpenses.get(position);

        // pojedinacan trosak na datum
        String oneCostCategory = costEntry.getCategory();
        String oneCostName = costEntry.getName();
        double oneCostValue = costEntry.getCost();
        int oneCostId = costEntry.getId();

        //Set values
        holder.tv_costDescription.setText(oneCostName);
        String oneCostValueString = "" + oneCostValue;      // converts int to String TODO how?
        holder.tv_costValue.setText(oneCostValueString + " kn");

        // setting imgv depending on category
        //todo ovdje mijenjaj imena kategorija
           switch (oneCostCategory) {
                case "Car":
                    holder.imgv_category.setBackgroundResource(R.drawable.car);
                    break;
                case "Clothes":
                    holder.imgv_category.setBackgroundResource(R.drawable.clothes);
                    break;
                case "Food":
                    holder.imgv_category.setBackgroundResource(R.drawable.food);
                    break;
                case "Utilities":
                    holder.imgv_category.setBackgroundResource(R.drawable.utilities);
                    break;
                case "Groceries":
                    holder.imgv_category.setBackgroundResource(R.drawable.groceries);
                    break;
                case "Education":
                    holder.imgv_category.setBackgroundResource(R.drawable.education);
                    break;
                case "Sport":
                    holder.imgv_category.setBackgroundResource(R.drawable.sport);
                    break;
               case "Cosmetics":
                   holder.imgv_category.setBackgroundResource(R.drawable.cosmetics);
                   break;
               case "Other":
                   holder.imgv_category.setBackgroundResource(R.drawable.other);
                   break;
                default:
                    break;
            }
    }

    /**
     * Returns the number of items to display.
     */
    @Override
    public int getItemCount() {
        if (mCostEntries == null) {
            return 0;
        }
        return mCostEntries.size();
    }

    public List<CostEntry> getDailyCosts() {
        return mCostEntries;
    }

    /**
     * When data changes, this method updates the list of costEntries
     * and notifies the adapter to use the new values on it
     */
    public void setmDailyCosts(List<CostEntry> costEntries) {
        mCostEntries = costEntries;
        notifyDataSetChanged();
    }

    public interface DailyItemClickListener {
        void onDailyItemClickListener(int itemId);
    }

    

    public class DailyCostViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView imgv_category;
        TextView tv_costDescription;
        TextView tv_costValue;

        /**
         * Constructor for the DailyCostViewHolders.
         *
         * @param itemView The view inflated in onCreateViewHolder
         */
        public DailyCostViewHolder(@NonNull View itemView) {
            super(itemView);
            // TextViews for itemView
            imgv_category = itemView.findViewById(R.id.imgv_category);
            tv_costDescription = itemView.findViewById(R.id.tv_costDescription);
            tv_costValue = itemView.findViewById(R.id.tv_costValue);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int elementId = mCostEntries.get(getAdapterPosition()).getId();
            mDailyItemClickListener.onDailyItemClickListener(elementId);
        }
    }

}
