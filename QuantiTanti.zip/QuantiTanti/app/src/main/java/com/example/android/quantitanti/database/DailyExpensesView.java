package com.example.android.quantitanti.database;

import androidx.room.DatabaseView;

@DatabaseView("SELECT DISTINCT date AS oneDate, SUM (cost) AS dailyCost FROM expenses" +
        " GROUP BY date ORDER BY date")

public class DailyExpensesView {

    public String oneDate;
    public double dailyCost;


    public String getOneDate() {
        return oneDate;
    }

    public double getDailyCost() {
        return dailyCost;
    }
}

